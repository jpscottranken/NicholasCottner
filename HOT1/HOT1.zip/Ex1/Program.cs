﻿using System;
using static System.Console;
/*
 * 
 * Write a C# program named ex1 that asks your name and prints the following message:
 * 
 * Hello, yourName! (where yourName is your full first, middle, and last name).
 * 
 * 
 */

namespace Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Hello, Nicholas Patrick Cottner!");
        }
    }
}
